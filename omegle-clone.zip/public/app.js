/* StrangerChat client */
const $ = s => document.querySelector(s);
let ws, myId, mode = 'text', partnerId = null, connected = false;
let pc = null, localStream = null;
const STUN = { iceServers: [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }] };

const statusEl = $('#status'), messagesEl = $('#messages'), inputEl = $('#input');

/* ---------- WebSocket ---------- */
function connect() {
  ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host);
  ws.onmessage = e => handle(JSON.parse(e.data));
  ws.onclose = () => { setStatus('Connection lost — reconnecting…', false);
    setTimeout(connect, 1500); };
}
connect();

function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }

function handle(m) {
  switch (m.t) {
    case 'welcome': myId = m.id; updateOnline(m.online); break;
    case 'online': updateOnline(m.count); break;
    case 'searching': setStatus('Looking for a stranger…', false); break;
    case 'matched': onMatched(m); break;
    case 'msg': addMsg('stranger', m.text); break;
    case 'typing': showTyping(); break;
    case 'signal': onSignal(m.data); break;
    case 'partner_left': onPartnerLeft(); break;
    case 'stopped': break;
  }
}

function updateOnline(n) { $('#onlineCount').textContent = n; }

/* ---------- UI helpers ---------- */
function setStatus(text, ok) {
  statusEl.textContent = text;
  statusEl.classList.toggle('connected', !!ok);
}
function addMsg(who, text) {
  const div = document.createElement('div');
  div.className = 'msg ' + who;
  div.textContent = text;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}
function showTyping() {
  const t = $('#typingHint');
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), 1800);
}

/* ---------- Home / mode select ---------- */
document.querySelectorAll('.mode-btn').forEach(b => b.onclick = () => {
  document.querySelectorAll('.mode-btn').forEach(x => x.classList.remove('active'));
  b.classList.add('active');
  mode = b.dataset.mode;
});

$('#startBtn').onclick = startChat;

async function startChat() {
  $('#home').classList.add('hidden');
  $('#chat').classList.remove('hidden');
  messagesEl.innerHTML = '';
  connected = false;

  if (mode === 'video') {
    $('#videoRow').classList.remove('hidden');
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      $('#localVideo').srcObject = localStream;
    } catch { addMsg('sys', '⚠️ Camera/microphone access denied — falling back to text.'); mode = 'text'; }
  } else {
    $('#videoRow').classList.add('hidden');
  }

  const interests = $('#interests').value.split(',').map(s => s.trim()).filter(Boolean);
  send({ t: 'find', mode, interests });
}

/* ---------- Matching ---------- */
function onMatched(m) {
  partnerId = m.with; connected = true;
  $('#typingHint').classList.add('hidden');
  setStatus('Connected — say hi! 👋', true);
  addMsg('sys', "You're now chatting with a random stranger.");

  const banner = $('#interestBanner');
  if (m.shared && m.shared.length) {
    banner.textContent = '🎯 You both like: ' + m.shared.join(', ');
    banner.classList.remove('hidden');
  } else if (m.peerInterests && m.peerInterests.length) {
    banner.textContent = '🎯 Stranger is interested in: ' + m.peerInterests.join(', ');
    banner.classList.remove('hidden');
  } else banner.classList.add('hidden');

  if (mode === 'video') setupPeer(m.initiator);
}

function onPartnerLeft() {
  addMsg('sys', 'Stranger has disconnected.');
  teardownPeer();
  connected = false;
  partnerId = null;
  setStatus('Stranger left — press New to find someone else.', false);
}

/* ---------- Text chat ---------- */
function sendMsg() {
  const text = inputEl.value.trim();
  if (!text || !connected) return;
  send({ t: 'msg', text });
  addMsg('you', text);
  inputEl.value = ''; inputEl.focus();
}
$('#sendBtn').onclick = sendMsg;
inputEl.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg(); } });
inputEl.addEventListener('input', () => { if (connected) send({ t: 'typing' }); });

/* ---------- Controls ---------- */
$('#nextBtn').onclick = nextStranger;
$('#stopBtn').onclick = stopChat;
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !$('#chat').classList.contains('hidden')) nextStranger();
});

function nextStranger() {
  teardownPeer();
  connected = false; partnerId = null;
  messagesEl.innerHTML = '';
  $('#interestBanner').classList.add('hidden');
  setStatus('Looking for a stranger…', false);
  send({ t: 'next' });
}

function stopChat() {
  teardownPeer();
  connected = false; partnerId = null;
  send({ t: 'stop' });
  $('#chat').classList.add('hidden');
  $('#home').classList.remove('hidden');
}

/* ---------- WebRTC video ---------- */
function setupPeer(initiator) {
  teardownPeer();
  pc = new RTCPeerConnection(STUN);
  localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
  pc.ontrack = e => { $('#remoteVideo').srcObject = e.streams[0]; };
  pc.onicecandidate = e => { if (e.candidate) send({ t: 'signal', data: { kind: 'ice', candidate: e.candidate } }); };
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
      addMsg('sys', 'Video connection lost.');
    }
  };
  if (initiator) {
    pc.createOffer().then(o => pc.setLocalDescription(o)).then(() =>
      send({ t: 'signal', data: { kind: 'sdp', sdp: pc.localDescription } }));
  }
}

async function onSignal(data) {
  if (!pc) return;
  try {
    if (data.kind === 'sdp') {
      await pc.setRemoteDescription(data.sdp);
      if (data.sdp.type === 'offer') {
        await pc.setLocalDescription(await pc.createAnswer());
        send({ t: 'signal', data: { kind: 'sdp', sdp: pc.localDescription } });
      }
    } else if (data.kind === 'ice') {
      await pc.addIceCandidate(data.candidate);
    }
  } catch (err) { console.error('signal error', err); }
}

function teardownPeer() {
  if (pc) { pc.close(); pc = null; }
  $('#remoteVideo').srcObject = null;
}
