# StrangerChat — Omegle-style anonymous chat

Random 1-on-1 chat with strangers. Text mode + WebRTC video mode, interest matching,
"New" (skip), Stop, typing indicator, live online counter. No accounts, fully anonymous.

## Features (mirrors Omegle)
- Random pairing with the next available stranger
- Text mode and video mode (WebRTC peer-to-peer video/audio)
- Interest tags — matched with strangers who share at least one interest
- "New" button / `Esc` key to jump to the next stranger instantly
- "Stop" to end the session
- Typing indicator, live online-user counter
- Auto-reconnect, graceful handling of disconnects

## Run locally
    npm install
    npm start
    # open http://localhost:3000 in two browser tabs

## Deploy live (free, ~10 minutes)

### Option A — Render (easiest)
1. Push this folder to a GitHub repo.
2. On https://render.com → New → Web Service → connect the repo.
3. Build command: `npm install`  |  Start command: `npm start`
4. Render gives you a URL like `https://yourapp.onrender.com` — that's your live site. WebSockets work out of the box.

### Option B — Railway
1. Push to GitHub, then https://railway.app → New Project → Deploy from GitHub.
2. Railway auto-detects Node and exposes `$PORT`. No config needed.

### Option C — Any VPS (Ubuntu)
    sudo apt install nodejs npm
    git clone <your-repo> && cd omegle-clone
    npm install
    npm start
Then put Nginx/Caddy in front with a free TLS cert (Caddy does it automatically):
    yourdomain.com {
        reverse_proxy localhost:3000
    }

## Notes
- Video uses public Google STUN servers, fine for most networks. For stricter NATs,
  add a TURN server (e.g. coturn) and add its credentials to `iceServers` in app.js.
- For production, add moderation/abuse reporting — anonymous chat platforms attract misuse
  and in many jurisdictions you must handle illegal content reports.
