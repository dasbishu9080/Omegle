const http = require('http');
const path = require('path');
const fs = require('fs');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;

// ---------- static file server ----------
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

const server = http.createServer((req, res) => {
  let filePath = path.join(__dirname, 'public',
    req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
  const ext = path.extname(filePath);
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
});

// ---------- matchmaking ----------
const wss = new WebSocketServer({ server });

let nextId = 1;
const clients = new Map(); // id -> { ws, mode, interests:[], partner:null, busy:false }

function send(ws, obj) { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); }

function tryMatch(entry) {
  // find someone in queue with same mode, not busy, not self
  for (const [id, c] of clients) {
    if (id === entry.id || c.partner || c.busy || c.mode !== entry.mode) continue;
    if (entry.mode === 'text') {
      const shared = entry.interests.filter(i => c.interests.includes(i));
      // if both typed interests, require at least one shared; otherwise match anyone
      if (entry.interests.length && c.interests.length && shared.length === 0) continue;
    }
    // match!
    c.partner = entry.id; entry.partner = id;
    c.busy = entry.busy = false;
    const shared = entry.interests.filter(i => c.interests.includes(i));
    send(c.ws, { t: 'matched', with: entry.id, shared, initiator: false,
                 peerInterests: entry.mode === 'text' ? entry.interests : [] });
    send(entry.ws, { t: 'matched', with: id, shared, initiator: true,
                 peerInterests: c.mode === 'text' ? c.interests : [] });
    return true;
  }
  return false;
}

function leaveQueue(id) {
  const c = clients.get(id);
  if (c) c.busy = false;
}

function disconnect(id, silent = false) {
  const c = clients.get(id);
  if (!c) return;
  if (c.partner) {
    const p = clients.get(c.partner);
    if (p) { p.partner = null; p.busy = false;
      if (!silent) send(p.ws, { t: 'partner_left' }); }
    c.partner = null;
  }
}

wss.on('connection', (ws) => {
  const id = nextId++;
  clients.set(id, { ws, mode: 'text', interests: [], partner: null, busy: false });
  send(ws, { t: 'welcome', id, online: clients.size });

  ws.on('message', (raw) => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    const c = clients.get(id);
    if (!c) return;

    switch (m.t) {
      case 'find': { // { mode:'text'|'video', interests:[] }
        disconnect(id, true);
        c.mode = m.mode === 'video' ? 'video' : 'text';
        c.interests = (m.interests || []).map(s => s.toLowerCase().trim()).filter(Boolean).slice(0, 5);
        c.busy = true;
        if (!tryMatch(c)) send(ws, { t: 'searching' });
        break;
      }
      case 'msg': { // text chat message
        const p = clients.get(c.partner);
        if (p) send(p.ws, { t: 'msg', from: 'stranger', text: String(m.text).slice(0, 2000) });
        break;
      }
      case 'typing': {
        const p = clients.get(c.partner);
        if (p) send(p.ws, { t: 'typing' });
        break;
      }
      case 'signal': { // WebRTC relay { data }
        const p = clients.get(c.partner);
        if (p) send(p.ws, { t: 'signal', data: m.data });
        break;
      }
      case 'next': { // find new stranger
        disconnect(id);
        c.busy = true;
        if (!tryMatch(c)) send(ws, { t: 'searching' });
        break;
      }
      case 'stop': { // end chat, back to home
        disconnect(id);
        c.busy = false;
        send(ws, { t: 'stopped' });
        break;
      }
    }
  });

  ws.on('close', () => {
    disconnect(id);
    clients.delete(id);
    broadcastOnline();
  });
});

function broadcastOnline() {
  for (const c of clients.values()) send(c.ws, { t: 'online', count: clients.size });
}
setInterval(broadcastOnline, 10000);

server.listen(PORT, () => console.log(`Running on http://localhost:${PORT}`));
